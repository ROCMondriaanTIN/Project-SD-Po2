// Voor toekomstige functies, bijvoorbeeld start-actie
document.querySelector(".start-btn").addEventListener("click", () => {
    alert("Start wordt geladen...");
});
